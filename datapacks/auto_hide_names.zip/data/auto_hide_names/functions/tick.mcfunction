execute as @a unless entity @s[team=HideNames] run team join HideNames @s
schedule function auto_hide_names:tick 1s