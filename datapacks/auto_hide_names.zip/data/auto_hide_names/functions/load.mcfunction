team add HideNames
team modify HideNames nametagVisibility never
team modify HideNames collisionRule never
gamerule showDeathMessages false
say [Datapack] Auto-hide names enabled!
schedule function auto_hide_names:tick 1s